# Version derives from DESCRIPTION; no manual update needed
get_digitize_date <- function()
{
  .module_banner("digitize")
}






################# main data structure ##############################
#dgtDataList
#dgtDataList[imgId][[1]]: speciman dir
#dgtDataList[imgId][[2]]: font
#dgtDataList[imgId][[3]]: number of landmark
#dgtDataList[1][[4]]: curves
#dgtDataList[imgId][[5]]: template
#dgtDataList[imgId][[6]]: rotation
#dgtDataList[imgId][[7]]: zoom
#dgtDataList[imgId][[8]]: surface file
#dgtDataList[imgId][[9]]: number of anchor points





#initializes parameters for digital component
init.digitize <- function(e)
{
  e$digData <- list()
  e$dragX <- as.integer(-1)
  e$dragY <- as.integer(-1)
  e$dragDot <- FALSE
  e$landmarkNum <- 5
  e$anchorNum <- 5
  # these variables are populated by a query of the C library code
  # they record the number of landmarks and the anchors resident in the C
  # code data structures for the specified array slice
  # these can be used to prevent adding redundant (duplicate) landmarks and anchors
  # as a result of changing specimens (NEXT / PREVIOUS) after landmarks an danchors have
  # been loaded, say as a result of reading a .dgt file
  e$landmarksPresentInMemory <- 0
  e$anchorsPresentInMemory <- 0
  e$lmkLoadedInC <- list()

  e$dColor <- c(1, 0, 0)     # initial dot color is RED
  e$daColor <- c(0, 1, 0)    # initial anchor color is GREEN
  if(0)
  {
    dbg("3dDigitize init.digitize");
  }
 	set("dot", "labeled", 1)
  set("dot", "alabeled", 1) #toggle for anchor point labels
  e$undo <- NULL
}


pushUndo <- function(e, entry) {
  e$undo <- entry
}


clearUndo <- function(e) {
  e$undo <- NULL
  e$dragDot <- FALSE
  e$dragX <- -1L
  e$dragY <- -1L
}


doUndo <- function(e) {
  if (is.null(e$undo)) {
    setStatus(e, "Nothing to undo", "warning")
    return(invisible())
  }

  entry <- e$undo
  scr <- entry$screen
  ok <- FALSE
  msg <- NULL

  if (entry$action == "place") {
    if (!set("dot", "selected", scr[1], scr[2])) {
      setStatus(e, "Nothing to undo", "warning")
      return(invisible())
    }
    if (entry$kind == "landmark") {
      del("dot")
      updateDotNum(e, -1)
      msg <- "Undid landmark placement"
      ok <- TRUE
    } else if (entry$kind == "anchor") {
      del("anchor")
      updateAnchorNum(e, -1)
      msg <- "Undid anchor placement"
      ok <- TRUE
    }
  } else if (entry$action == "delete") {
    coord <- entry$coord
    if (entry$kind == "landmark") {
      if (TRUE == add("dot", coord[1], coord[2], coord[3])) {
        updateDotNum(e, 1)
        msg <- "Undid landmark deletion"
        ok <- TRUE
      }
    } else if (entry$kind == "anchor") {
      if (TRUE == add("anchor", coord[1], coord[2], coord[3])) {
        updateAnchorNum(e, 1)
        msg <- "Undid anchor deletion"
        ok <- TRUE
      }
    }
  } else if (entry$action == "move") {
    before <- entry$before
    # Re-select at release screen (where marker sits after drag); fall back to
    # drag-start screen if the user rotated/zoomed before Ctrl+Z.
    selected <- set("dot", "selected", scr[1], scr[2])
    if (!selected && !is.null(entry$screenStart)) {
      selected <- set("dot", "selected", entry$screenStart[1], entry$screenStart[2])
    }
    if (selected) {
      set("dot", "coordinate", before[1], before[2], before[3])
      msg <- if (entry$kind == "anchor") "Undid anchor move" else "Undid landmark move"
      ok <- TRUE
    }
  } else if (entry$action == "curve_place") {
    curves <- e$activeDataList[[1]][[4]]
    if (!is.matrix(curves) || nrow(curves) < 1L) {
      setStatus(e, "Nothing to undo", "warning")
      return(invisible())
    }
    if (nrow(curves) == 1L) {
      e$activeDataList[[1]][[4]] <- matrix(numeric(0), nrow = 0, ncol = 3)
    } else {
      e$activeDataList[[1]][[4]] <- curves[-nrow(curves), , drop = FALSE]
    }
    remaining <- e$activeDataList[[1]][[4]]
    if (!is.matrix(remaining) || nrow(remaining) < 1L) {
      .clearAllCurves(e)
    } else {
      .redrawAllCurves(e)
    }
    msg <- "Undid curve segment placement"
    ok <- TRUE
  }

  if (ok) {
    clearUndo(e)
    setStatus(e, msg, "info")
  } else {
    setStatus(e, "Nothing to undo", "warning")
  }
  invisible()
}


.overrideCtrlZ <- function(widget, e) {
  tkbind(widget, "<Control-z>", function() {
    doUndo(e)
    tcl("break")
  })
}



#draw widgets for digitize tab
ui.digitize <- function(e, parent)
{
  digCtlFrame <- ttkframe(parent)
  e$bt <- NULL

  setScaleBtn <-
    ttkbutton(
      digCtlFrame,
      text = "Digitize scale",
      command = function()
        setScale(e)
    )
  e$scaleLabel <- ttklabel(digCtlFrame, text = "Scale Factor: not set")

  e$lmCountVar <- tclVar(as.character(e$landmarkNum))
  e$lmCountSpin <-
    ttkspinbox(
      digCtlFrame,
      from = 1,
      to = 100,
      increment = 1,
      textvariable = e$lmCountVar,
      width = 5,
      command = function()
        onLmCountChange(e)
    )
  tkbind(e$lmCountSpin, "<Return>", function() {
    onLmCountChange(e)
  })
  tkbind(e$lmCountSpin, "<FocusOut>", function() {
    onLmCountChange(e)
  })
  e$lmCountLabel <- ttklabel(digCtlFrame, text = "Fixed landmarks")
  loadLandmarkBtn <-
    ttkbutton(
      digCtlFrame,
      text = "Load landmarks",
      command = function()
        loadLandmark(e)
    )

  #e$path <- tclVar("Path:")
  #e$imgPath = tkentry(digCtlFrame, textvariable=e$path, state="disabled")

  fitBtn <-
    ttkbutton(
      digCtlFrame,
      text = "Fit",
      command = function()
        onFit(e)
    )

  e$labelLandmarkVar <- tclVar("1")
  labelLandmark <-
    ttkcheckbutton(
      digCtlFrame,
      text = "Label Landmark",
      variable = e$labelLandmarkVar,
      command = function()
        onLabelLandMark(e)
    )

  e$placeAnchorsVar <- tclVar("0")
  placeAnchors <-
    ttkcheckbutton(
      digCtlFrame,
      text = "Place Anchors",
      variable = e$placeAnchorsVar,
      command = function() {
        onPlaceAnchor(e)
      }
    )
  assign("bt", placeAnchors, envir = e)


  #####################################
  e$lmSizeVar <- tclVar("0.01")
  e$lmSizeScale <-
    ttkscale(
      digCtlFrame,
      from = 0.001,
      to = 0.050,
      variable = e$lmSizeVar,
      command = function(...)
        onLmSizeSlide(e, "radius")
    )

  lmColorFrame <- ttkframe(digCtlFrame)
  lmColorBtn <-
    ttkbutton(
      lmColorFrame,
      text = "Landmark Color",
      command = function()
        onLmColorChange(e)
    )
  e$lmColorLabel <-
    tklabel(
      lmColorFrame,
      text = 'aa',
      foreground = '#ff0000',
      background = '#ff0000'
    )
  sapply(list(lmColorBtn, e$lmColorLabel),
         tkpack,
         side = "left",
         padx = 3)

  e$specimenNumLabel <-
    ttklabel(digCtlFrame, text = "Number of Specimens: 0")
  e$landMarkNumLabel <-
    ttklabel(digCtlFrame, text = "Number of Landmarks: 0")

  e$missLandmarkVar <- tclVar("0")
  e$missLandmarkCheBtn <-
    ttkcheckbutton(digCtlFrame,
                   text = "Missing Landmark",
                   variable = e$missLandmarkVar)

  tkpack(ttklabel(digCtlFrame, text = " "), pady = 6)
  sapply(
    list(
      e$lmCountLabel,
      e$lmCountSpin,
      loadLandmarkBtn,
      fitBtn,
      e$lmSizeScale,
      lmColorFrame,
      labelLandmark,
      placeAnchors,
      e$specimenNumLabel,
      e$landMarkNumLabel
    ),
    tkpack,
    pady = 3
  )
  .overrideCtrlZ(e$lmCountSpin, e)
  return (digCtlFrame)
}





#draw widgets for anchor tab
ui.anchor <- function(e, parent)
{
  anchorCtlFrame <- ttkframe(parent)

  e$anchorCountVar <- tclVar(as.character(e$anchorNum))
  e$anchorCountSpin <-
    ttkspinbox(
      anchorCtlFrame,
      from = 1,
      to = 100,
      increment = 1,
      textvariable = e$anchorCountVar,
      width = 5,
      command = function()
        onAnchorCountChange(e)
    )
  tkbind(e$anchorCountSpin, "<Return>", function() {
    onAnchorCountChange(e)
  })
  tkbind(e$anchorCountSpin, "<FocusOut>", function() {
    onAnchorCountChange(e)
  })

  fitBtn <-
    ttkbutton(
      anchorCtlFrame,
      text = "Fit",
      command = function()
        onFit(e)
    )

  e$labelAnchorVar <- tclVar("1")
  labelAnchor <-
    ttkcheckbutton(
      anchorCtlFrame,
      text = "Label Anchors",
      variable = e$labelAnchorVar,
      command = function()
        onLabelAnchor(e)
    )

  e$anchorNumLabel <-
    ttklabel(anchorCtlFrame, text = "Number of Anchors: 0")
  e$specimenNumLabel2 <-
    ttklabel(anchorCtlFrame, text = "Number of Specimens: 0")

  e$anchorSizeVar <- tclVar("0.01")
  e$anchorSizeScale <-
    ttkscale(
      anchorCtlFrame,
      from = 0.001,
      to = 0.050,
      variable = e$anchorSizeVar,
      command = function(...)
        onLmSizeSlide(e, "anchorRadius")
    )

  anchorColorFrame <- ttkframe(anchorCtlFrame)
  anchorColorBtn <-
    ttkbutton(
      anchorColorFrame,
      text = "Anchor Color",
      command = function()
        onAnchorColorChange(e)
    )
  e$anchorColorLabel <-
    tklabel(
      anchorColorFrame,
      text = 'aa',
      foreground = '#00ff00',
      background = '#00ff00'
    )
  sapply(
    list(anchorColorBtn, e$anchorColorLabel),
    tkpack,
    side = "left",
    padx = 3
  )

  tkpack(ttklabel(anchorCtlFrame, text = " "), pady = 6)
  sapply(
    list(
      e$anchorCountSpin,
      fitBtn,
      e$anchorSizeScale,
      anchorColorFrame,
      labelAnchor,
      e$specimenNumLabel2,
      e$anchorNumLabel
    ),
    tkpack,
    pady = 3
  )
  .overrideCtrlZ(e$anchorCountSpin, e)
  return (anchorCtlFrame)


}





#configures buttons for digitize component
bind.digitize <- function(e)
{
  tkbind(e$canvasFrame, "<MouseWheel>", function(D) {
    zoom(e, normalizeWheelDelta(D))
  })

  tkbind(e$canvasFrame, "<ButtonPress-1>", function(x, y) {
    onLeftBtnPress(e, x, y)
  })

  tkbind(e$canvasFrame, "<ButtonRelease-1>", function(x, y) {
    onLeftBtnRelease(e, x, y)
  })

  bindDeleteGesture(e$canvasFrame, function(x, y) {
    deleteLandmark(e, x, y)
  })

  tkbind(e$canvasFrame, "<Motion>", function(x, y) {
    motion(e, x, y)
  }) #motion - events are generated when pointer is moved


  tkbind(e$canvasFrame, "<Double-Button-1>", function(x, y) {
    addDot(e, x, y) #Here is where double clicking calls the addDot function on canvas to place a landmark
  })
}




bind.anchor <- function(e)
{
  tkbind(e$canvasFrame, "<MouseWheel>", function(D) {
    zoom(e, normalizeWheelDelta(D))
  })

  tkbind(e$canvasFrame, "<ButtonPress-1>", function(x, y) {
    onLeftBtnPress(e, x, y)
  })

  tkbind(e$canvasFrame, "<ButtonRelease-1>", function(x, y) {
    onLeftBtnRelease(e, x, y)
  })

  bindDeleteGesture(e$canvasFrame, function(x, y) {
    deleteAnchor(e, x, y)
  })

  tkbind(e$canvasFrame, "<Motion>", function(x, y) {
    motion(e, x, y)
  }) #motion - events are generated when pointer is moved

  tkbind(e$canvasFrame, "<Double-Button-1>", function(x, y) {
    addAnchor(e, x, y)
  })
}





#changes color of landmark
onLmColorChange <- function(e)
{
  color <- tcl('tk_chooseColor')
  tkconfigure(
    e$lmColorLabel,
    text = 'aa',
    foreground = tclvalue(color),
    background = tclvalue(color)
  )
  color <- as.integer(gsub("#", "0x", tclvalue(color)))

  r <- as.integer(color / 0x10000)
  g <- as.integer((color %% 0x10000) / 0x100)
  b <- as.integer(color %% 0x100)
  e$dColor <- c(r / 255, g / 255, b / 255)
  set("dot", "dcolor", r / 255, g / 255, b / 255)
}


onAnchorColorChange <- function(e)
{
  color <- tcl('tk_chooseColor')
  tkconfigure(
    e$anchorColorLabel,
    text = 'aa',
    foreground = tclvalue(color),
    background = tclvalue(color)
  )
  color <- as.integer(gsub("#", "0x", tclvalue(color)))

  r <- as.integer(color / 0x10000)
  g <- as.integer((color %% 0x10000) / 0x100)
  b <- as.integer(color %% 0x100)
  e$daColor <- c(r / 255, g / 255, b / 255)
  set("dot", "acolor", r / 255, g / 255, b / 255)
}

#Sets action for dragging dots
onLeftBtnPress <- function(e, x, y)
{
  ##print ("onLeftBtnPress ... ")
  ##print (paste ("active data list : ", e$activeDataList) )
  ##print (paste ("         length  : ", length(e$activeDataList) ))

  if (0 == e$tab)
  {
    dbg("e$tab is 0 : DIGITIZE")
  }

  if (1 == e$tab)
  {
    dbg("e$tab is 1 : ANCHORS")
  }

  if (2 == e$tab)
  {
    dbg("e$tab is 2 : SURFACE")
  }

  if (3 == e$tab)
  {
    dbg("e$tab is 3 : CURVES")
  }

  if (4 == e$tab)
  {
    dbg("e$tab is 4 : GPA")
  }



  if (length(e$activeDataList) > 0)
  {
    if (e$tab == 1)   ## this means we are on the anchors tab
    {

      ##print ("onLeftBtnPress ... calling set dot selected ... e$tab == 1")
      ##print (paste("  calling set/dot/selected :",x,y))

      result <- set("dot", "selected", x, y)

      ##print("onLeftBtnPress ... result from set dot selected ... ")
      ##print(result)

      if (result)
      {
        e$dragDot <- TRUE
        e$dragStartCoord <- convertCoor(e, x, y)
        e$dragStartScreen <- c(as.integer(x), as.integer(y))
        set(
          "dot",
          "anchorColor",
          as.double(1 / 255),
          as.double(164 / 255),
          as.double(191 / 255)
        )
      }
      else
      {
        e$dragDot <- FALSE
      }
    }
    else
    {

      ##print (paste("e$tab is : ", e$tab))
      ##print ("calling set dot selected ... else ... e$tab is NOT 1")
      ##print (paste("calling set/dot/selected :",x,y))

      result <- set("dot", "selected", x, y)

      ##print(paste ("3dDigitize.digitize line 463 result is : ", result))

      if (TRUE == result)
      {
        e$dragDot <- TRUE
        e$dragStartCoord <- convertCoor(e, x, y)
        e$dragStartScreen <- c(as.integer(x), as.integer(y))
        set("dot", "color", as.double(1 / 255), as.double(164 / 255),  as.double(191 / 255))
      }
      else
      {
        e$dragDot <- FALSE
      }
    }


    # wondering if assigning the drag variables should be conditioned on
    # the starus of e$dragDot
    e$dragX <- as.integer(x)
    e$dragY <- as.integer(y)
    ##print (paste (" line 481 ... drags : ", e$dragX, e$dragY))
  }
  ##print ("onLeftBtnPress ... end ")
}



#assigns chosen color value to selected dot
onLeftBtnRelease <- function(e, x, y)
{
  ##print ("onLeftBtnrelease ... ")
  if (length(e$activeDataList) > 0)
  {
    wasDragging <- e$dragDot
    e$dragX <- as.integer(-1)
    e$dragY <- as.integer(-1)

    if (wasDragging)
    {
      e$dragDot <- FALSE
      if (e$tab == 1)
      {
        color <- e$daColor
        ##print ("ready to call set dot anchorColor")
        set("dot", "anchorColor", color[1], color[2], color[3])
      }
      else
      {
        ##print ("ready to call set dot color")
        color <- e$dColor
        set("dot", "color", color[1], color[2], color[3])
      }

      after <- convertCoor(e, x, y)
      if (!is.null(e$dragStartCoord) &&
          sum((e$dragStartCoord - after)^2) > 1e-12) {
        pushUndo(e, list(
          action = "move",
          kind = if (e$tab == 1) "anchor" else "landmark",
          before = e$dragStartCoord,
          after = after,
          screen = c(as.integer(x), as.integer(y)),
          screenStart = e$dragStartScreen
        ))
      }
    }
  }
  ##print ("onLeftBtnrelease ... end ")
}






# Live size slider: quantize to 0.001 grain, push to renderer, persist in [[2]]
onLmSizeSlide <- function(e, attr)
{
  if (length(e$activeDataList) == 0) {
    return()
  }

  raw <- as.numeric(tclvalue(if (attr == "radius") e$lmSizeVar else e$anchorSizeVar))
  v <- round(raw / 0.001) * 0.001
  set("dot", attr, v)
  e$activeDataList[[e$currImgId]][[2]] <- v
}


onLmCountChange <- function(e)
{
  floor <- if (length(e$activeDataList) > 0)
    max(1L, as.integer(e$activeDataList[[e$currImgId]][[3]]))
  else
    1L
  val <- suppressWarnings(as.integer(tclvalue(e$lmCountVar)))
  if (is.na(val) || val < floor)
    val <- floor
  if (val > 100L)
    val <- 100L
  tclvalue(e$lmCountVar) <- as.character(val)
  e$landmarkNum <- val
}


onAnchorCountChange <- function(e)
{
  floor <- if (length(e$activeDataList) > 0)
    max(1L, as.integer(e$activeDataList[[e$currImgId]][[9]]))
  else
    1L
  val <- suppressWarnings(as.integer(tclvalue(e$anchorCountVar)))
  if (is.na(val) || val < floor)
    val <- floor
  if (val > 100L)
    val <- 100L
  tclvalue(e$anchorCountVar) <- as.character(val)
  e$anchorNum <- val
}





#draw label for landmark
onLabelLandMark <- function(e)
{
  dbg("onLabelLandMark")
  if (length(e$activeDataList) == 0)
  {
    return()
  }


  if (tclvalue(e$labelLandmarkVar) == "1")
  {
    dbg("Calling set dot labeled 1")
    set("dot", "labeled", 1)
  }
  else
  {
    dbg("Calling set dot labeled 0")
    set("dot", "labeled", 0)
  }
}



#draw label for anchor
onLabelAnchor <- function(e)
{
  #print("onLabelLandMark")
  if (length(e$activeDataList) == 0) {
    return()
  }

  if (tclvalue(e$labelAnchorVar) == "1")
  {
    set("dot", "alabeled", 1)
  }
  else
  {
    set("dot", "alabeled", 0)
  }
}




onPlaceAnchor <- function(e)
{
  if (length(e$activeDataList) == 0) {
    return()
  }

  refreshTabGating(e)
  updateStepLabel(e)
}








#Pop up window for setting number of landmarks
setLandmarkNum <- function(e)
{
  win <- tktoplevel()
  tkwm.title(win, "Set Landmark Number")

  entryFrame <- ttkframe(win)
  tkpack(
    entryFrame,
    expand = TRUE,
    fill = "both",
    padx = 5,
    pady = 5
  )
  label = tklabel(entryFrame, text = 'Set landmark Number: ')

  e$landmarkEntry = tkentry(entryFrame, textvariable = tclVar(e$landmarkNum))
  sapply(list(label, e$landmarkEntry),
         tkpack,
         side = "left",
         padx = 6)

  btnFrame <- ttkframe(win)
  tkpack(btnFrame,
         fill = "x",
         padx = 5,
         pady = 5)
  cancelBtn <-
    ttkbutton(
      btnFrame,
      text = "cancel",
      command = function()
        tkdestroy(win)
    )
  okBtn <-
    ttkbutton(
      btnFrame,
      text = "ok",
      command = function()
        onlandmarkNumOk(e, win)
    )

  tkpack(
    ttklabel(btnFrame, text = " "),
    expand = TRUE,
    fill = "y",
    side = "left"
  )
  sapply(list(cancelBtn, okBtn),
         tkpack,
         side = "left",
         padx = 6)

  tkfocus(win)
}






#Pop up window for setting number of anchors
setAnchorNum <- function(e)
{
  win <- tktoplevel()
  tkwm.title(win, "Set Anchor Number")

  entryFrame <- ttkframe(win)
  tkpack(
    entryFrame,
    expand = TRUE,
    fill = "both",
    padx = 5,
    pady = 5
  )
  label = tklabel(entryFrame, text = 'Set anchor Number: ')

  e$anchorEntry = tkentry(entryFrame, textvariable = tclVar(e$anchorNum))
  sapply(list(label, e$anchorEntry),
         tkpack,
         side = "left",
         padx = 6)

  btnFrame <- ttkframe(win)
  tkpack(btnFrame,
         fill = "x",
         padx = 5,
         pady = 5)
  cancelBtn <-
    ttkbutton(
      btnFrame,
      text = "cancel",
      command = function()
        tkdestroy(win)
    )
  okBtn <-
    ttkbutton(
      btnFrame,
      text = "ok",
      command = function()
        onanchorNumOk(e, win)
    )

  tkpack(
    ttklabel(btnFrame, text = " "),
    expand = TRUE,
    fill = "y",
    side = "left"
  )
  sapply(list(cancelBtn, okBtn),
         tkpack,
         side = "left",
         padx = 6)

  tkfocus(win)
}





#loads landmark file
loadLandmark <- function(e)
{
  fileStr <-
    tclvalue(
      tkgetOpenFile(
        filetypes = "{{landmark file} {.pts}} {{csv file} {.csv}} {{All files} *}",
        multiple = FALSE,
        title = "Select landmark file"
      )
    )
  .warnUnexpectedExtension(fileStr, c("pts", "csv"), "Load landmarks")
  add("landmark", e$currImgId - 1, e$landmarkNum, fileStr)
  e$activeDataList[[e$currImgId]][[3]] <- e$landmarkNum
  tkconfigure(e$landMarkNumLabel,
              text = paste("Number of Landmarks: ", e$landmarkNum))
  refreshTabGating(e)
  updateStepLabel(e)
}





#pop up window to remove selected landmark
deleteLandmark <- function(e, x, y)
{
  if (length(e$activeDataList) == 0) {
    return()
  }

  if (set("dot", "selected", x, y)) {
    coord <- convertCoor(e, x, y)
    del("dot")
    updateDotNum(e, -1)
    pushUndo(e, list(
      action = "delete",
      kind = "landmark",
      coord = coord,
      screen = c(as.integer(x), as.integer(y))
    ))
  } else {
    .setMissStatus(e, "Landmark delete")
  }
}




deleteAnchor <- function(e, x, y)
{
  if (length(e$activeDataList) == 0) {
    return()
  }

  if (set("dot", "selected", x, y)) {
    coord <- convertCoor(e, x, y)
    del("anchor")
    updateAnchorNum(e, -1)
    pushUndo(e, list(
      action = "delete",
      kind = "anchor",
      coord = coord,
      screen = c(as.integer(x), as.integer(y))
    ))
  } else {
    .setMissStatus(e, "Anchor delete")
  }
}




# Guard against the Tk multi-click cascade: only <Double-Button-1> is bound for
# placement, and Tk re-fires that binding for the 3rd/4th clicks of a rapid burst
# (no <Triple-Button-1>/<Quadruple-Button-1> binding to absorb them). One jittery
# double/triple-click can therefore call addDot/addAnchor several times a few
# pixels apart, placing phantom points. Treat a placement that lands within a few
# pixels of the previous one within 400 ms as the same gesture and ignore it. A
# deliberate second placement is always farther away and/or slower, so normal
# double-click placement (which fires the handler exactly once) is unaffected.
.placeIsDuplicate <- function(e, x, y)
{
  now <- as.numeric(Sys.time())
  xi <- as.integer(x)
  yi <- as.integer(y)
  prev <- e$lastPlace
  dup <- FALSE
  if (!is.null(prev) &&
      (now - prev$t) < 0.4 &&
      abs(xi - prev$x) <= 8 &&
      abs(yi - prev$y) <= 8)
  {
    dup <- TRUE
  }
  e$lastPlace <- list(t = now, x = xi, y = yi)
  dup
}

.setMissStatus <- function(e, action)
{
  if (is.null(e$statusLabel))
    return(invisible(FALSE))
  setStatus(
    e,
    paste0(action, " missed the specimen surface; no changes were applied."),
    "warning"
  )
  invisible(TRUE)
}


#adds one landmark
addDot <- function(e, x, y)
{
  dbg(paste("line 908 : function addDot : ", x, y))
  if (.placeIsDuplicate(e, x, y))
  {
    dbg("INFO : ignoring duplicate landmark from multi-click burst")
    return(invisible())
  }
  if (length(e$activeDataList) > 0)
  {
    dotNum <- e$activeDataList[[e$currImgId]][[3]]
    dbg(paste("dotNum raw : ", dotNum+1, "-of- ",  e$landmarkNum ))

    if (dotNum < as.integer(e$landmarkNum))
    {

      coord <- convertCoor(e, x, y)
      ## print (paste ("these are the coordinates generated by R :", coord [1], coord[2], coord[3]))

      ## This is provided for manual capture of digitized points for future testing needs
      dbg("LANDMARK : Coordinate Data for post processing use : ")
      dbg( paste( "x y, X,Y, Z : ", x, y, coord [1], coord[2], coord[3]))


      result <- add("dot", coord[1], coord[2], coord[3])
      dbg(paste("LINE 929 !  Result from add dot ...", result))

      if (TRUE == result)
      {
        dbg(coord)
        updateDotNum(e, 1)
        pushUndo(e, list(
          action = "place",
          kind = "landmark",
          coord = coord,
          screen = c(as.integer(x), as.integer(y))
        ))
      }
      else
      {
        dbg("WARNING : add dot : not inside the specimen")
        .setMissStatus(e, "Landmark placement")
      }
    }
  }
  else
  {
    dbg("WARNING : no specimen opened")
  }
}






#adds one anchor point
addAnchor <- function(e, x, y)
{
  dbg(paste("line 954 : function addAnchor : ", x, y))
  if (.placeIsDuplicate(e, x, y))
  {
    dbg("INFO : ignoring duplicate anchor from multi-click burst")
    return(invisible())
  }
  if (length(e$activeDataList) > 0)
  {
    anchorNum <- e$activeDataList[[e$currImgId]][[9]]
    dbg(paste("dotNum raw : ", anchorNum+1, "-of- ",  e$anchorNum ))

    if (anchorNum < as.integer(e$anchorNum))
    {
      coord <- convertCoor(e, x, y)

      ## This is provided for manual capture of digitized points for future testing needs
      dbg("ANCHOR : Coordinate Data for post processing use : ")
      dbg( paste( "x y,  X,Y,  Z : ", x, y, coord [1], coord[2], coord[3]))



      if (TRUE == add("anchor", coord[1], coord[2], coord[3]))
      {
        updateAnchorNum(e, 1)
        pushUndo(e, list(
          action = "place",
          kind = "anchor",
          coord = coord,
          screen = c(as.integer(x), as.integer(y))
        ))
      }
      else
      {
        dbg("WARNING : place anchor : not inside the specimen")
        .setMissStatus(e, "Anchor placement")
      }
    }
  }
  else
  {
    dbg("WARNING : no specimen opened")
  }
}


#updates real number of landmarks in database after deletion or insertion of landmark
updateDotNum <- function(e, delt)
{
  nDots <- e$activeDataList[[e$currImgId]][[3]]
  nDots <- nDots + delt
  tkconfigure(e$landMarkNumLabel, text = paste("Number of Landmarks: ", nDots))
  e$activeDataList[[e$currImgId]][[3]] <- nDots
  dbg(paste("Updated number of (landmarks) dots", nDots))

  if (!is.null(e$lmCountSpin)) {
    tkconfigure(e$lmCountSpin, from = max(1L, as.integer(nDots)))
  }


  refreshTabGating(e)
  updateStepLabel(e)

  nTarget <- as.integer(e$landmarkNum)
  if (!is.null(e$statusLabel)) {
    if (nDots < nTarget) {
      setStatus(e,
        paste0("Place all ", nTarget, " landmarks before continuing \u2014 ",
               nDots, " of ", nTarget, " placed."),
        "warning")
    } else {
      setStatus(e,
        paste0("Specimen ", e$currImgId, " of ", length(e$activeDataList),
               " \u2014 ", basename(e$activeDataList[[e$currImgId]][[1]])),
        "neutral")
    }
  }

}


updateAnchorNum <- function(e, delt)
{
  nAnchors <- e$activeDataList[[e$currImgId]][[9]]
  nAnchors <- nAnchors + delt
  tkconfigure(e$anchorNumLabel, text = paste("Number of Anchors: ", nAnchors))
  e$activeDataList[[e$currImgId]][[9]] <- nAnchors
  dbg(paste("Updated number of (anchors) dots", nAnchors))

  if (!is.null(e$anchorCountSpin)) {
    tkconfigure(e$anchorCountSpin, from = max(1L, as.integer(nAnchors)))
  }


  refreshTabGating(e)
  updateStepLabel(e)

  nTarget <- as.integer(e$anchorNum)
  if (!is.null(e$statusLabel) &&
      tclvalue(e$placeAnchorsVar) == "1") {
    if (nAnchors < nTarget) {
      setStatus(e,
        paste0("Place all ", nTarget, " anchors before continuing \u2014 ",
               nAnchors, " of ", nTarget, " placed."),
        "warning")
    } else {
      setStatus(e,
        paste0("Specimen ", e$currImgId, " of ", length(e$activeDataList),
               " \u2014 ", basename(e$activeDataList[[e$currImgId]][[1]])),
        "neutral")
    }
  }
}



#updates real values for widgets
updateWidgets.digitize <- function(e)
{
  #print("updateWidgets.digitize ")
  if (length(e$activeDataList) == 0) {
    return()
  }

  dotNum <- e$activeDataList[[e$currImgId]][[3]]
  sz <- e$activeDataList[[e$currImgId]][[2]]
  tclvalue(e$lmSizeVar) <- as.character(sz)
  tclvalue(e$lmCountVar) <- as.character(as.integer(e$landmarkNum))
  if (!is.null(e$lmCountSpin)) {
    tkconfigure(e$lmCountSpin, from = max(1L, as.integer(dotNum)))
  }
  tkconfigure(e$landMarkNumLabel, text = paste("Number of Landmarks: ", dotNum))
  tkconfigure(e$imgPath, text = paste0("Specimen ", e$currImgId, " of ", length(e$activeDataList)))
}




updateWidgets.anchor <- function(e)
{
  if (length(e$activeDataList) == 0) {
    return()
  }

  anchorNum <- e$activeDataList[[e$currImgId]][[9]]
  sz <- e$activeDataList[[e$currImgId]][[2]]
  tclvalue(e$anchorSizeVar) <- as.character(sz)
  tclvalue(e$anchorCountVar) <- as.character(as.integer(e$anchorNum))
  if (!is.null(e$anchorCountSpin)) {
    tkconfigure(e$anchorCountSpin, from = max(1L, as.integer(anchorNum)))
  }
  tkconfigure(e$anchorNumLabel, text = paste("Number of Anchors: ", anchorNum))
  tkconfigure(e$imgPath, text = paste0("Specimen ", e$currImgId, " of ", length(e$activeDataList)))
}




#reads .dgt files
read.digitize <- function(e, content)
{
  dbg("file 3dDigitize.digitize ... function read.digitize")
  ignore.case = TRUE
  lmdata <- grep("LM3=", content, ignore.case)
  nlands <-
    as.numeric(sub("LM3=", "", content[lmdata], ignore.case))
  k <- 3

  if (max(nlands) - min(nlands) != 0)
  {
    stop("Number of landmarks not the same for all specimens.")
  }

  nSpecimen <- length(lmdata)
  nland <- nlands[1]

  startLines <- lmdata + 1
  endLines <- as.numeric(lmdata) + as.numeric(nlands)
  coords <- array(0, c(nland, 3, nSpecimen))

  for (i in 1:nSpecimen)
  {
    tmp <- content[startLines[i]:endLines[i]]
    coords[, , i] <-
      matrix(as.numeric(unlist(strsplit(tmp, " "))), ncol = 3, byrow = TRUE)
  }

  # 5/4/2020 - EOC added conditional statement to check whether .dgt ID (each .ply file)
  # already includes a file path
  # or if the path to the .dgt file needs to be added to each .ply file

  if (grepl("/.", sub("ID=", "", content[grep("ID=", content, ignore.case)], ignore.case)[1])) {
    ID <-
      sub("ID=", "", content[grep("ID=", content, ignore.case)], ignore.case)
  }
  else
  {
    ID <- paste(e$dgtPath, "/",
                sub("ID=", "", content[grep("ID=", content, ignore.case)], ignore.case), sep =
                  "")
    dbg("line 958")
  }


  if (grepl("/.", sub("ID=", "", content[grep("ID=", content, ignore.case)], ignore.case)[1])) {
    ID <-
      sub("ID=", "", content[grep("ID=", content, ignore.case)], ignore.case)
  }
  else
  {
    ID <- paste(e$dgtPath, "/",
                sub("ID=", "", content[grep("ID=", content, ignore.case)], ignore.case), sep =
                  "")
    dbg("line 971")
  }


  dbg(ID)
  if (length(ID) != 0)
  {
    dimnames(coords)[[3]] <- as.list(ID)
  }



  dbg("file 3dDigitize.digitize ... function read.digitize ... end")
  return(coords)
}







read.anchors <- function(content)
{
  ignore.case <- TRUE
  acdata <- grep("AC3=", content, ignore.case)
  nanchors <- as.numeric(sub("AC3=", "", content[acdata], ignore.case))

  if (anyNA(nanchors))
  {
    #make more robust
    dbg("Missing anchors")
    return()
  }
  else
  {
    if (max(nanchors) - min(nanchors) != 0)
    {
      stop("Number of anchors not the same for all specimens.")
    }
  }

  nSpecimen <- length(acdata)
  nanchor <- nanchors[1]

  startLines <- acdata + 1
  endLines <- as.numeric(acdata) + as.numeric(nanchors)
  coords <- array(0, c(nanchor, 3, nSpecimen))

  for (i in 1:nSpecimen)
  {
    tmp <- content[startLines[i]:endLines[i]]
    coords[, , i] <-
      matrix(as.numeric(unlist(strsplit(tmp, " "))), ncol = 3, byrow = TRUE)
  }

  ID <- sub("ID=", "", content[grep("ID=", content, ignore.case)], ignore.case)
  #print(paste ("File names associated with anchors is ", ID))
  if (length(ID) != 0)
  {
    dimnames(coords)[[3]] <- as.list(ID)
  }

  for (ii in 1:(length(ID)) )
  {
    dbg( paste( "read.anchors : file name ", ii, ":", ID[ii] ) )
  }

  return(coords)
}





#writes data to .dgt file
write.digitize <- function(fileName, Id, landmarks, anchors)
{
  lmline <- paste("LM3=", nrow(landmarks), sep = "")
  write(lmline, fileName, append = TRUE)
  write.table(
    landmarks,
    fileName,
    col.names = FALSE,
    row.names = FALSE,
    append = TRUE
  )
}

write.anchors <- function(fileName, Id, anchors)
{
  acline <- paste("AC3=", nrow(anchors), sep = "")
  write(acline, fileName, append = TRUE)
  if (length(anchors) != 0)
    write.table(
      anchors,
      fileName,
      col.names = FALSE,
      row.names = FALSE,
      append = TRUE
    )
  else
    write("NULL", fileName, append = TRUE)
  idline <- paste("ID=", Id, sep = "")
  write(idline, fileName, append = TRUE)
}

# displays specimen and landmark in canvas
# specimen numbers are 1 based !
draw.digitize <- function(e, id, specimen, landmarks)
{
  sliceID <- id
  add("queryFromR", 1, sliceID)
  lmQuery <- suppressWarnings(as.integer(
    tclvalue(tcl("add", "queryFromR", 2, sliceID, 0))
  ))
  if (is.na(lmQuery)) lmQuery <- 0L
  e$landmarksPresentInMemory <- lmQuery
  alreadyLoaded <- isTRUE(e$lmkLoadedInC[[as.character(id)]])
  dbg(paste("landmarks already in C code", lmQuery, "R-tracked loaded:", alreadyLoaded))

  if (!alreadyLoaded && lmQuery == 0L)
  {
    dbg(paste("loading PLY file for specimen ", id))
    add("specimen", specimen, id)   # load model in
    set("specimen", "id", id)

    # --- only push dots if this specimen actually has landmarks ---
    if (!is.null(landmarks) && nrow(landmarks) > 0)
    {
      add("SetLandmarkIndex", id, -1, -2)
      for (j in 1:nrow(landmarks))
      {
        add("rawdot", landmarks[j, 1], landmarks[j, 2], landmarks[j, 3])
      }
      add("InfoLandmarks_complete", 1, -1, -2)
      e$lmkLoadedInC[[as.character(id)]] <- TRUE
    }
  }
  else
  {
    dbg("landmarks already loaded in memory ... skipped adding more landmarks")
    add("specimen", specimen, id)
    set("specimen", "id", id)
  }

  add("queryFromR", 1, sliceID)
  add("queryFromR", 2, sliceID)
}


draw.anchors <- function(e, id, anchors)
{
  if (!is.null(anchors) && nrow(anchors) > 0 && !anyNA(anchors))
  {
    if (0 == e$anchorsPresentInMemory)
    {
      add("SetAnchorIndex", id, 0, 0)
      messageToC(paste("function draw.anchors : id ", id))
      for (j in 1:nrow(anchors))
      {
        add("rawanchor", anchors[j, 1], anchors[j, 2], anchors[j, 3])
      }
      add("InfoAnchors_complete", 0, 0, 0)
    }
    else
    {
      dbg("anchors already loaded in memory ... skipped adding more anchors")
    }
  }
  else
  {
    dbg("Missing or empty anchors ... nothing to draw")
    return()
  }
  return()
}
